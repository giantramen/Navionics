//
//  NavionicsMobileSDK.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NavionicsMobileSDK.
FOUNDATION_EXPORT double NavionicsMobileSDKVersionNumber;

//! Project version string for NavionicsMobileSDK.
FOUNDATION_EXPORT const unsigned char NavionicsMobileSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NavionicsMobileSDK/PublicHeader.h>

#import <NavionicsMobileSDK/NMSEnums.h>
#import <NavionicsMobileSDK/NMSGeoObjectResultsDelegate.h>
#import <NavionicsMobileSDK/NavionicsMobileServices.h>
#import <NavionicsMobileSDK/NMSMapView.h>
#import <NavionicsMobileSDK/NMSOverlay.h>
#import <NavionicsMobileSDK/NMSCircle.h>
#import <NavionicsMobileSDK/NMSPolygon.h>
#import <NavionicsMobileSDK/NMSPolyline.h>
#import <NavionicsMobileSDK/NMSMarker.h>
#import <NavionicsMobileSDK/NMSGroundOverlay.h>
#import <NavionicsMobileSDK/NMSPath.h>
#import <NavionicsMobileSDK/NMSMutablePath.h>
#import <NavionicsMobileSDK/NMSCoordinateBounds.h>
#import <NavionicsMobileSDK/NMSCameraPosition.h>
#import <NavionicsMobileSDK/NMSGeoObject.h>
#import <NavionicsMobileSDK/NMSGeoObjectStandard.h>
#import <NavionicsMobileSDK/NMSGeoObjectTide.h>
#import <NavionicsMobileSDK/NMSGeoObjectCurrent.h>
#import <NavionicsMobileSDK/NMSGeoObjectPP.h>
#import <NavionicsMobileSDK/NMSSettings.h>
#import <NavionicsMobileSDK/NMSMapSettings.h>
