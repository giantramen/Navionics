//
//  NMSSettings.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NMSEnums.h"

/*! 
 @class NMSSettings
 @brief Navionics Mobile SDK settings
 */
@interface NMSSettings : NSObject

/*!
 * @brief Builds and returns the default @c NMSSettings.
 * @return the @c NMSSettings object
 */
+ (instancetype)settings;

/*! @brief the preferred language*/
@property(nonatomic,assign)NMSLanguage language;

/*!
 * @brief the framework mode
 * @discussion set @c NMSFrameworkModeSandbox for your test build or @c NMSFrameworkModeStore for your market build.
 */
@property(nonatomic,assign)NMSFrameworkMode mode;

/*!
 * @brief the framework activation token
 * @discussion get an activation token using the navionics developer portal by providing a private key and the bundle identifier.
 */
@property(nonatomic,retain)NSString* projectToken;

/*! @brief the private key*/
@property(nonatomic,retain)NSString* privateKey;

@end
