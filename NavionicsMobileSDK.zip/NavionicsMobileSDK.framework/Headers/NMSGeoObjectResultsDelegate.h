//
//  NMSGeoObjectResultsDelegate.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#ifndef NMSGeoObjectResultsDelegate_h
#define NMSGeoObjectResultsDelegate_h

#import "NMSGeoObject.h"
#import "NMSEnums.h"

/*! @brief Geo Object Retrieving Protocol. */
@protocol NMSGeoObjectResultsDelegate <NSObject>

/*!
 * @brief Receive the searches results. @c searchGeoObjectsByName: and @c searchGeoObjectsByCategory:
 * @param results The results array. Incrementally updated with the results
 * @param status The search status.
 */
-(void)searchGeoObjectDidReceiveResults:(NSArray<NMSGeoObject*>*)results withStatus:(NMSGeoObjectSearchStatus)status;

/*!
 * @brief Receive the map querying results. @c geoObjectsAtPoint:
 * @param results The results array.
 */
-(void)geoObjectsAtPointDidReceiveResults:(NSArray<NMSGeoObject*>*)results;

@end


#endif /* NMSGeoObjectResultsDelegate_h */
