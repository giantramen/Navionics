//
//  NMSOverlay.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
@class NMSMapView;

/*! @brief  Abstract class that represents some overlay that may be attached to a specific @c NMSMapView */
@interface NMSOverlay : NSObject

/*! @brief Title, a short description of the overlay. */
@property(nonatomic, retain)NSString* title;

/*! @brief Higher zIndex value overlays will be drawn on top of lower zIndex value tile layers and overlays. */
@property(nonatomic, assign)NSUInteger zIndex;

/*! @brief The map this overlay is on. */
@property(nonatomic, assign)NMSMapView* map;

@end
