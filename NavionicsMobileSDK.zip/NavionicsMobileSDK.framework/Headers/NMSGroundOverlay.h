//
//  NMSGroundOverlay.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSOverlay.h"
#import <UIKit/UIKit.h>
#import "NMSCoordinateBounds.h"

/*! @brief An image overlay on the Earth's surface */
@interface NMSGroundOverlay : NMSOverlay

/*!
 * @brief Convenience constructor for @c NMSGroundOverlay for a particular bounds and image.
 * @param bounds The 2D bounds on the Earth in which image is drawn.
 * @param image Image to render within bounds on the Earth.
 * @return the @c NMSGroundOverlay object
 */
+ (instancetype) groundOverlayWithBounds:(NMSCoordinateBounds*)bounds image:(UIImage*)image;

/*! @brief The 2D bounds on the Earth in which image is drawn.  */
@property(nonatomic, copy)NMSCoordinateBounds* bounds;

/*! @brief Image to render within bounds on the Earth. */
@property(nonatomic, retain)UIImage* image;

/*! @brief Bearing of this ground overlay, in degrees.  */
@property(nonatomic, assign) CLLocationDirection bearing;

/*! @brief The anchor specifies where this @c NMSGroundOverlay is anchored to the Earth in relation to bounds.  */
@property(nonatomic, assign) CGPoint anchor;

/*! @brief Sets the opacity of the ground overlay, between 0 (completely transparent) and 1 (default) inclusive. */
@property(nonatomic, assign)CGFloat opacity;

@end
