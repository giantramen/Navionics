//
//  NMSEnums.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#ifndef NMSEnums_h
#define NMSEnums_h

/*! @brief  Available search categories*/
typedef enum NMSSearchCategory
{
    NMSSearchCategoryHarborMaster,
    NMSSearchCategoryMarinasMoorings,
    NMSSearchCategorySkiResort,
    NMSSearchCategoryFuelStation,
    NMSSearchCategoryRestaurant,
    NMSSearchCategoryLift,
    NMSSearchCategoryRefuge,
    NMSSearchCategorySportShop,
    NMSSearchCategoryTaxi,
    NMSSearchCategoryRepair,
    NMSSearchCategoryTide,
    NMSSearchCategoryCurrent,
    NMSSearchCategoryDealer,
    NMSSearchCategoryLake,
    NMSSearchCategoryTicketOffice,
    NMSSearchCategorySkiSchool,
    NMSSearchCategorySkiRental,
    NMSSearchCategoryFirstAid,
    NMSSearchCategorySnowPark,
    NMSSearchCategoryHotel,
    NMSSearchCategoryMountainPeak,
    NMSSearchCategorySkiTrail,
    NMSSearchCategoryAirportServices,
    NMSSearchCategoryOtherPoi
}NMSSearchCategory;

/*! @brief  Available objects type*/
typedef enum NMSGeoObjectType
{
    NMSGeoObjectTypeStandard,
    NMSGeoObjectTypeTide,
    NMSGeoObjectTypeCurrent,
    NMSGeoObjectTypePP
}NMSGeoObjectType;

/*! @brief  Search Process status*/
typedef enum NMSGeoObjectSearchStatus
{
    NMSGeoObjectSearchStart,
    NMSGeoObjectSearchInProgress,
    NMSGeoObjectSearchEnd,
}NMSGeoObjectSearchStatus;

/*! @brief Supported Languages*/
typedef enum NMSLanguage
{
    NMSLanguageAuto,
    NMSLanguageEnglish,
    NMSLanguageFrench,
    NMSLanguageSpanish,
    NMSLanguageItalian,
    NMSLanguageGerman
}NMSLanguage;

typedef enum NMSFrameworkMode
{
    NMSFrameworkModeSandbox,
    NMSFrameworkModeProduction
}NMSFrameworkMode;

/*! @brief Depth Density*/
typedef enum NMSDepthContoursDensity
{
    NMSDepthContoursDensityLow,
    NMSDepthContoursDensityMedium,
    NMSDepthContoursDensityHigh,
    NMSDepthContoursDensityVeryHigh
}NMSDepthContoursDensity;

/*! @brief Depth Units*/
typedef enum NMSDepthUnit
{
    NMSDepthUnitMeters,
    NMSDepthUnitFeet,
    NMSDepthUnitFathoms
}NMSDepthUnit;

/*! @brief Speed Units*/
typedef enum NMSSpeedUnit
{
    NMSSpeedUnitKnots,
    NMSSpeedUnitMPH,
    NMSSpeedUnitKPH
}NMSSpeedUnit;

/*! @brief Distance Units*/
typedef enum NMSDistanceUnit
{
    NMSDistanceUnitKilometers,
    NMSDistanceUnitNauticalMiles,
    NMSDistanceUnitStatuteMiles
}NMSDistanceUnit;

/*! @brief Map Mode*/
typedef enum NMSMapMode
{
    NMSMapModeDefault,
    NMSMapModeSonarCharts
}NMSMapMode;

/*! @brief Map Settings Type*/
typedef enum NMSMapSettingsType
{
    NMSMapSettingsTypeStandard,
    NMSMapSettingsTypeAdvanced
    
}NMSMapSettingsType;

/*! @brief GPS Mode*/
typedef enum NMSGPSMode
{
    NMSGPSModeUnlinked,
    NMSGPSModeNorthUp,
    NMSGPSModeCompass,
    NMSGPSModeCourseUp,
    NMSGPSModeCourseUpUnlinked
}NMSGPSMode;

/*! @brief Error Codes*/
typedef enum NMSErrorCode
{
    NMSErrorUnknown = -1000,
    NMSErrorInvalidTokenOrKey = -1,
    NMSErrorInvalidSanboxToken = -2,
    NMSErrorInvalidProductionToken = -3,
    NMSErrorInvalidToken = -4,
    NMSErrorEmptyTokenOrKey = -5,
    NMSErrorMissingResources = -6,
    NMSErrorMissingLocationBackgroundMode = -7
}NMSErrorCode;

#endif /* NMSEnums_h */
