//
//  NavionicsMobileServices.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import "NMSEnums.h"
#import "NMSGeoObjectResultsDelegate.h"

@class NMSSettings;

/*! 
 @class NavionicsMobileServices
 @brief Main class of the Navionics Mobile Services and is the entry point for all the available services 
 */
@interface NavionicsMobileServices : NSObject

/*!
 * @brief Initialize the SDK accordingly with the settings.
 * @param settings The input SDK settings
 * @return YES if the SDK has been initialized succesfully.
 */
+ (BOOL)initializeWithSettings:(NMSSettings*)settings error:(NSError**)error;

/*!
 * @brief Shutdown the SDK.
 * @discussion Reset all the previous initialization settings. After the shutdown the SDK needs to be initialized again.
 */
+ (void)shutDown;

/*!
 * @brief Retrieve cartographic objects in a given map view point.
 * @discussion The results will be provided using the @c NSMGeoObjectResultsDelegate protocol.
 * @param point The map view point
 * @return YES if the functionality is available
 */
+ (BOOL)geoObjectsAtPoint:(CGPoint)point;

/*!
 * @brief Search cartographic object by name.
 * @discussion The results will be provided using the @c NSMGeoObjectResultsDelegate protocol.
 * @param name string to search
 * @return YES if the functionality is available
 */
+ (BOOL)searchGeoObjectsByName:(NSString*)name;

/*!
 * @brief Search cartographic object by category.
 * @discussion The results will be provided using the @c NSMGeoObjectResultsDelegate protocol.
 * @param category The category of the objects to search
 * @return YES if the functionality is available
 */
+ (BOOL)searchGeoObjectsByCategory:(NMSSearchCategory)category;

/*!
 * @brief Set the object that implements @c NSMGeoObjectResultsDelegate protocol.
 * @discussion This delegate will receive the results of cartographic objects retrieving APIs.
 * @param delegate The delegate
 * @return YES if the delegate has been set succesfully.
 */
+ (BOOL)setGeoObjectsResultsDelegate:(id<NMSGeoObjectResultsDelegate>)delegate;

/*!
 * @brief Enable the login UI.
 * @discussion If the user is already logged shown the user details.
 */
+ (void)navionicsUser;

/*!
 * @brief Check User login status.
 * @return YES if the user is logged in.
 */
+ (BOOL)isNavionicsUserLoggedIn;

/*!
 * @brief Enable the manual download UI on the map.
 * @discussion The download UI will appear only on the active map (if any).
 * @return YES if is possible to enable the download UI on an active map.
 */
+ (BOOL)enableDownloadAreaSelector;

/*!
 * @brief Disable the manual download UI on the map and confim of cancel the download.
 * @discussion The download UI will disappear. The download procedure for the selected area will start only if the download confirmation flag is YES.
 * @param confirmDownload The download confirmation flag
 * @return YES if is possible to disable the download UI on an active map.
 */
+ (BOOL)disableDownloadAreaSelectorAndConfirm:(BOOL)confirmDownload;

/*!
 * @brief Enable the GPS Services.
 * @discussion The framework needs location update as required background modes.
 * @return YES if GPS services has been enabled (the app has the user authorization).
 */
+ (BOOL)enableGPSServices;

/*!
 * @brief Disable the GPS Services.
 * @discussion The framework needs location update as required background modes.
 * @return YES if GPS services has been disabled.
 */
+ (BOOL)disableGPSServices;

/*!
 * @brief Framework version.
 * @return The framework version string.
 */
+ (NSString*)version;

@end
