//
//  NMSCoordinateBounds.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@class NMSPath;

/*! @brief Rectangular bounding box on the Earth's surface */
@interface NMSCoordinateBounds : NSObject

/*!
 * @brief Inits the northEast and southWest bounds corresponding to the rectangular region defined by the two corners.
 * @param firstCoordinate A corner coordinate.
 * @param secondCoordinate A corner coordinate.
 * @return the @c NMSCoordinateBounds object
 */
- (id)initWithCoordinate:(CLLocationCoordinate2D)firstCoordinate coordinate:(CLLocationCoordinate2D)secondCoordinate;

/*!
 * @brief Inits the northEast and southWest bounds that encompass path.
 * @param path The path to contain.
 * @return the @c NMSCoordinateBounds object
 */
- (id)initWithPath:(NMSPath*)path;

/*!
 * @brief Returns a @c NMSCoordinateBounds representing the current bounds extended to include the passed-in coordinate.
 * @param coordinate The coordinate to include.
 * @return the @c NMSCoordinateBounds object
 */
- (NMSCoordinateBounds *)includingCoordinate:(CLLocationCoordinate2D)coordinate;

/*!
 * @brief Returns a @c NMSCoordinateBounds representing the current bounds extended to include the entire other bounds.
 * @param bounds The bounds to include.
 * @return the @c NMSCoordinateBounds object
 */
- (NMSCoordinateBounds *)includingBounds:(NMSCoordinateBounds*)bounds;

/*!
 * @brief Returns YES if coordinate is contained within this bounds.
 * @param coordinate The coordinate.
 * @return YES if coordinate is contained within this bounds.
 */
- (BOOL)containsCoordinate:(CLLocationCoordinate2D)coordinate;

/*!
 * @brief Returns YES if other bounds overlaps with this bounds.
 * @param bounds The bounds.
 * @return YES if bounds overlaps with this bounds.
 */
- (BOOL)intersectsBounds:(NMSCoordinateBounds*)bounds;

/*!
 * @brief Returns YES if other bounds is equal to this bounds.
 * @param bounds The bounds.
 * @return YES if bounds is equal to this bounds.
 */
- (BOOL)isEqualToBounds:(NMSCoordinateBounds*)bounds;

/*! @brief The North-East corner of these bounds.  */
@property(nonatomic,readonly)CLLocationCoordinate2D northEast;

/*! @brief The South-West corner of these bounds.  */
@property(nonatomic,readonly)CLLocationCoordinate2D southWest;

/*! @brief Returns NO if this bounds does not contain any points.  */
@property(nonatomic,readonly)BOOL valid;

@end
