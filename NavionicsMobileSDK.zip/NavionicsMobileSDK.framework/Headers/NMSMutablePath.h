//
//  NMSMutablePath.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSPath.h"

/*! @brief Dynamic array of @c CLLocationCoordinate2D */
@interface NMSMutablePath : NMSPath

/*!
* @brief Adds coordinate at the end of the path.
* @param coordinate the coordinate to add
*/
- (void)addCoordinate:(CLLocationCoordinate2D)coordinate;

/*!
 * @brief Adds coordinate at index.
 * @param coordinate the coordinate to add
 * @param index the index
 */
- (void)insertCoordinate:(CLLocationCoordinate2D)coordinate atIndex:(NSUInteger)index;

/*!
 * @brief Replace the coordinate at index with new coordinate.
 * @param coordinate the new coordinate
 * @param index the index
 */
- (void)replaceCoordinateAtIndex:(NSUInteger)index withCoordinate:(CLLocationCoordinate2D)coordinate;

/*!
 * @brief Remove coordinate at index.
 * @param index the index
 */
- (void)removeCoordinateAtIndex:(NSUInteger)index;

/*! @brief Removes the last coordinate of the path.  */
- (void)removeLastCoordinate;

/*! @brief Removes all coordinates in this path. */
- (void)removeAllCoordinates;

@end
