//
//  NMSCameraPosition.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreGraphics/CoreGraphics.h>

/*! @brief Camera position parameters */
@interface NMSCameraPosition : NSObject

/*!
* @brief Convenience constructor for @c NMSCameraPosition for a particular target and zoom level
* @param target The target position
* @param zoom The target zoom level
* @return the @c NMSCameraPosition object
*/
+ (instancetype)cameraWithTarget:(CLLocationCoordinate2D)target zoom:(float)zoom;

/*!
 * @brief Convenience constructor for @c NMSCameraPosition for a particular latitude, longitude and zoom level
 * @param latitude The target position latitude
 * @param longitude The target position longitude
 * @param zoom The target zoom level
 * @return the @c NMSCameraPosition object
 */
+ (instancetype)cameraWithLatitude:(CLLocationDegrees)latitude longitude:(CLLocationDegrees)longitude zoom:(float)zoom;

/*!
 * @brief Convenience constructor for @c NMSCameraPosition for a particular target, zoom level and bearing
 * @param target The target position
 * @param zoom The target zoom level
 * @param bearing The map bearing 
 * @return the @c NMSCameraPosition object
 */
+ (instancetype)cameraWithTarget:(CLLocationCoordinate2D)target zoom:(float)zoom bearing:(CLLocationDirection)bearing;

/*!
 * @brief Convenience constructor for @c NMSCameraPosition for a particular target and zoom level
 * @param latitude The target position latitude
 * @param longitude The target position longitude
 * @param zoom The target zoom level
 * @param bearing The map bearing
 * @return the @c NMSCameraPosition object
 */
+ (instancetype)cameraWithLatitude:(CLLocationDegrees)latitude longitude:(CLLocationDegrees)longitude zoom:(float)zoom bearing:(CLLocationDirection)bearing;

/*!
 * @brief Get the zoom level at which meters distance, at given coord on Earth, correspond to the specified number of screen points.
 * @param coordinate The position
 * @param meters The distance in meters
 * @param points The number of screen points
 * @return the zoom level
 */
+ (float)zoomAtCoordinate:(CLLocationCoordinate2D)coordinate forMeters:(CLLocationDistance)meters perPoints:(CGFloat)points;

/*! @brief Location on the Earth towards which the camera points.  */
@property(nonatomic,assign)CLLocationCoordinate2D target;

/*! @brief Zoom level.  */
@property(nonatomic,assign)float zoom;

/*! 
 * @brief Bearing of the camera, in degrees clockwise from true north.
 * @discussion It is possible read the bearing value when the map is rotated because of the GPS (@c NMSGPSModeCompass and @c NMSGPSModeCourseUp mode).
 * @discussion It is not supported the map rotation by changing the bearing value.
 */
@property(nonatomic,assign)CLLocationDirection bearing;

@end
