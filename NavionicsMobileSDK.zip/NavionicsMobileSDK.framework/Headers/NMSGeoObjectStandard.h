//
//  NMSGeoObjectStandard.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSGeoObject.h"

/*! @brief Represents a standard cartographic object */
@interface NMSGeoObjectStandard : NMSGeoObject

@end
