//
//  NMSGeoObjectTide.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSGeoObject.h"
#import <UIKit/UIKit.h>

/*!
 * @brief Tide samples
 * @discussion the samples are loaded as detailed data of the @c NMSGeoObjectTide. Contains all the tide height values and icons for a predefined time interval.
 */
@interface NMSGeoObjectTideSamples : NSObject

/*!
 * @brief Returns the icon for a samples
 * @param index The index of the sample
 * @return The icon
 */
-(UIImage*)iconForSampleAtIndex:(NSUInteger)index;

/*!
 * @brief Returns the height value in the current depth unit
 * @param index The index of the sample
 * @return The height value
 */
-(double)heightForSampleAtIndex:(NSUInteger)index;

/*!
 * @brief Returns the sample date.
 * @param index The index of the sample
 * @return The date
 */
-(NSDate*)dateForSampleAtIndex:(NSUInteger)index;

/*! @brief The samples count */
@property(nonatomic,readonly)NSUInteger count;

@end

/*! @brief Represents a Tide */
@interface NMSGeoObjectTide : NMSGeoObject

/*!
 * @brief The prediction date of the tide
 * @discussion by changing the prediction date the icon is updated and all the detailed data are invalidated. To get the updated tide samples loads again the detailed data.
 */
@property(nonatomic,retain)NSDate* predictionDate;

@end
