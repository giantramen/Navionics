//
//  NMSGeoObjectPP.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSGeoObject.h"
#import <UIKit/UIKit.h>

/*! @brief Represents a Panoramic Photo */
@interface NMSGeoObjectPP : NMSGeoObject

/*!
 * @brief The photo image
 * @discussion is nil after the retrieving. Is loaded as detailed data of the geo object.
 */
@property(nonatomic,readonly)UIImage* image;

@end
