//
//  NMSPolygon.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSOverlay.h"
#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>

@class NMSPath;

/*! @brief A polygon on the Earth's surface */
@interface NMSPolygon : NMSOverlay

/*!
 * @brief Convenience constructor for @c NMSPolygon for a particular path.
 * @param path The path that describes this polygon.
 * @return the @c NMSPolygon object
 */
+ (instancetype)polygonWithPath:(NMSPath*)path;

/*! @brief The path that describes this polygon. */
@property(nonatomic, retain)NMSPath* path;

/*! 
 * @brief The array of @c NMSPath instances that describes any holes in this polygon.
 * @discussion Not Supported in this version
 */
@property(nonatomic, retain)NSArray<NMSPath*>* holes;

/*! @brief The width of the polygon outline in screen points. */
@property(nonatomic, assign)CGFloat strokeWidth;

/*! @brief The color of the polygon outline. */
@property(nonatomic, retain)UIColor* strokeColor;

/*! @brief The fill color. */
@property(nonatomic, retain)UIColor* fillColor;

@end
