//
//  NMSGeoObject.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>
#import "NMSEnums.h"

/*! @brief Abstract class that represents a cartographic object */
@interface NMSGeoObject : NSObject

/*! @brief The type of the geo object */
@property(nonatomic,readonly)NMSGeoObjectType type;

/*! @brief The position of the geo object */
@property(nonatomic,readonly)CLLocationCoordinate2D position;

/*! @brief The icon representing the geo object symbol */
@property(nonatomic,readonly)UIImage* icon;

/*!
 * @brief The details dictionary
 * @discussion After the retrieving, the geo object will contains only the name as details. To load all the data of the object calls @c -(void)loadDetailsWithCompletionBlock:
 */
@property(nonatomic,readonly)NSDictionary* details;

/*! @brief YES if all the detailed data of the object has been loaded */
@property(nonatomic,readonly)BOOL detailsLoaded;

/*!
 * @brief Loads asynchronously the detailed data of the geo object
 * @param completion The completion block to execute at the end of the loading process
 */
-(void)loadDetailsWithCompletionBlock:(void (^)(NMSGeoObject* detailedObject))completion;

@end
