//
//  NMSMarker.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSOverlay.h"
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreGraphics/CoreGraphics.h>

/*! @brief Icon placed at a particular point on the map's surface */
@interface NMSMarker : NMSOverlay

/*!
 * @brief Convenience constructor for a default @c NMSMarker
 * @param position Marker position.
 * @return the @c NMSMarker object
 */
+ (instancetype)markerWithPosition:(CLLocationCoordinate2D)position;

/*! @brief Marker position. */
@property(nonatomic, assign)CLLocationCoordinate2D position;

/*! 
 * @brief Snippet text
 * @discussion Not Supported in this version
 */
@property(nonatomic, retain)NSString* snippet;

/*! @brief Marker icon to render. */
@property(nonatomic, retain)UIImage* image;

/*! @brief Sets the opacity of the marker, between 0 (completely transparent) and 1 (default) inclusive. */
@property(nonatomic, assign)CGFloat opacity;

/*! @brief The anchor specifies the point in the icon image that is anchored to the marker's position on the Earth's surface.  */
@property(nonatomic, assign)CGPoint anchor;

@end
