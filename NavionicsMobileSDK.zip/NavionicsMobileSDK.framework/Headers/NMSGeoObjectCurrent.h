//
//  NMSGeoObjectCurrent.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSGeoObject.h"
#import <UIKit/UIKit.h>

/*!
 * @brief Current samples
 * @discussion the samples are loaded as detailed data of the @c NMSGeoObjectCurrent. Contains all the current speeds, directions and icons for a predefined time interval.
 */
@interface NMSGeoObjectCurrentSamples : NSObject

/*!
 * @brief Returns the icon for a samples
 * @param index The index of the sample
 * @return The icon
 */
-(UIImage*)iconForSampleAtIndex:(NSUInteger)index;

/*!
 * @brief Returns the direction value.
 * @param index The index of the sample
 * @return The direction value
 */
-(double)directionForSampleAtIndex:(NSUInteger)index;

/*!
 * @brief Returns the speed value in the current speed unit
 * @param index The index of the sample
 * @return The speed value
 */
-(double)speedForSampleAtIndex:(NSUInteger)index;

/*!
 * @brief Returns the sample date.
 * @param index The index of the sample
 * @return The date
 */
-(NSDate*)dateForSampleAtIndex:(NSUInteger)index;

/*! @brief The samples count */
@property(nonatomic,readonly)NSUInteger count;

@end

/*! @brief Represents a Current */
@interface NMSGeoObjectCurrent : NMSGeoObject

/*!
 * @brief The prediction date of the current
 * @discussion by changing the prediction date the icon is updated and all the detailed data are invalidated. To get the updated current samples loads again the detailed data.
 */
@property(nonatomic,retain)NSDate* predictionDate;

@end
