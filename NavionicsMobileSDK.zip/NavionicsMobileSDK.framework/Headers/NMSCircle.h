//
//  NMSCircle.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSOverlay.h"
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreGraphics/CoreGraphics.h>

/*! @brief A circle on the Earth's surface */
@interface NMSCircle : NMSOverlay

/*!
 * @brief Convenience constructor for @c NMSCircle for a particular position and radius.
 * @param position Position on Earth of circle center.
 * @param radius Radius of the circle in meters; must be positive.
 * @return the @c NMSCircle object
 */
+ (instancetype) circleWithPosition:(CLLocationCoordinate2D)position radius:(float)radius;

/*! @brief Position on Earth of circle center. */
@property(nonatomic, assign)CLLocationCoordinate2D position;

/*! @brief Radius of the circle in meters; must be positive. */
@property(nonatomic, assign)CLLocationDistance radius;

/*! @brief The width of the circle's outline in screen points. */
@property(nonatomic, assign)CGFloat strokeWidth;

/*! @brief The color of this circle's outline. */
@property(nonatomic, retain)UIColor* strokeColor;

/*! @brief The interior of the circle is painted with fillColor. */
@property(nonatomic, retain)UIColor* fillColor;


@end
