//
//  NMSPolyline.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import "NMSOverlay.h"
#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>

@class NMSPath;

/*! @brief A polyline on the Earth's surface*/
@interface NMSPolyline : NMSOverlay

/*!
 * @brief Convenience constructor for @c NMSPolyline for a particular path.
 * @param path The path that describes this polyline.
 * @return the @c NMSPolyline object
 */
+ (instancetype)polylineWithPath:(NMSPath*)path;

/*! @brief The path that describes this polyline. */
@property(nonatomic, retain)NMSPath* path;

/*! @brief The width of the line in screen points. */
@property(nonatomic, assign)CGFloat strokeWidth;

/*! @brief The color used to render the polyline. */
@property(nonatomic, retain)UIColor* strokeColor;

@end
