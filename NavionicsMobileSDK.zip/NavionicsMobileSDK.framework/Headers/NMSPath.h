//
//  NMSPath.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

/*! @brief Array of @c CLLocationCoordinate2D*/
@interface NMSPath : NSObject


/*!
 * @brief Convenience constructor for an empty path.
 */
+ (instancetype)path;

/*!
 * @brief Initializes a newly allocated path with the contents of another NMSPath.
 * @param path the path
 */
- (id)initWithPath:(NMSPath*)path;

/*!
 * @brief Get size of path.
 * @return The count of the path points
 */
- (NSUInteger)count;

/*!
 * @brief Returns a path coordinate in specific index
 * @param index The path index
 * @return @c kCLLocationCoordinate2DInvalid if |index| >= count. A valid coordinate otherwise.
 */
- (CLLocationCoordinate2D)coordinateAtIndex:(NSUInteger)index;

@end
