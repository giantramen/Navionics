//
//  NMSMapView.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "NMSEnums.h"

@class NMSCameraPosition;
@class NMSMapSettings;
@class NMSMapView;

@protocol NMSMapViewDelegate <NSObject>

- (void)mapView:(NMSMapView *)mapView didChangeCameraPosition:(NMSCameraPosition *)position;

@end

/*! @brief View that contains the map. Only one map view can be active at any given time. */
@interface NMSMapView : UIView

/*!
* @brief Builds and returns a @c NMSMapView.
* @param frame The map view frame
* @return the @c NMSMapView object
*/
+ (NMSMapView*)mapWithFrame:(CGRect)frame;

/*!
 * @brief Move the camera of this map to position. Animated if animate flag is enabled
 * @param position the camera position
 * @param animate animation flag
 * @return YES if it is possible to move the map
 */
- (BOOL)moveToCameraPosition:(NMSCameraPosition*)position animated:(BOOL)animate;

/*!
 * @brief As moveToCameraPosition:, but changes only the location of the camera
 * @param location the target position
 * @param animate animation flag
 * @return YES if it is possible to move the map
 */
- (BOOL)moveToLocation:(CLLocationCoordinate2D)location animated:(BOOL)animate;

/*!
 * @brief As moveToCameraPosition:, but changes only the zoom of the camera
 * @param zoom the target zoom level
 * @param animate animation flag
 * @return YES if it is possible to move the map
 */
- (BOOL)moveToZoom:(float)zoom animated:(BOOL)animate;

/*!
 * @brief As moveToCameraPosition:, but changes only the location and the zoom of the camera
 * @param location the target position
 * @param zoom the target zoom level
 * @param animate animation flag
 * @return YES if it is possible to move the map
 */
- (BOOL)moveToLocation:(CLLocationCoordinate2D)location andZoom:(float)zoom animated:(BOOL)animate;

/*!
 * @brief Zoom in the camera. Animated if animate flag is enabled
 * @param animate animation flag
 * @return YES if it is possible to move the map
 */
- (BOOL)zoomInAnimated:(BOOL)animate;

/*!
 * @brief Zoom out the camera. Animated if animate flag is enabled
 * @param animate animation flag
 * @return YES if it is possible to move the map
 */
- (BOOL)zoomOutAnimated:(BOOL)animate;


/*!
 * @brief convert a map view point in the corresponding coordinate
 * @param point the view point
 * @return the coordinate if the view point is within the map view rect, @ckCLLocationCoordinate2DInvalid otherwise
 */
- (CLLocationCoordinate2D)coordinateForPoint:(CGPoint)point;

/*!
 * @brief Activate the map. Only one map view can be active at any given time.
 * @return YES if it is possible to activate the map
 */
- (BOOL)activate;

/*! @brief Remove all the overlay linked to the map. */
- (void)clearOverlays;

/*! @brief Settings to modify the map appearance. */
@property(nonatomic, copy)NMSMapSettings* settings;
/*! @brief The current camera position. */
@property(nonatomic, readonly)NMSCameraPosition* camera;
/*! @brief Set the GPS Mode. GPS Services must be enabled */
@property(nonatomic, assign)NMSGPSMode gpsMode;
/*! @brief NMSMapView delegate */
@property(nonatomic, assign)id<NMSMapViewDelegate> delegate;

@end
