//
//  NMSMapSettings.h
//  NavionicsMobileSDK
//
//  Copyright © 2016 Navionics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NMSEnums.h"

/*! @brief Dynamic settings of the map */
@interface NMSMapSettings : NSObject

/*!
 * @brief Builds and returns the default @c NMSSettings.
 * @return the @c NMSSettings object, nil if NavionicsMobileServices is not initialized.
 */
+(instancetype)mapSettings;

/*! @brief The map settings type
 *  @discussion @c NMSMapSettingsTypeAdvanced when the logged user has at least one valid subcription, @c NMSMapSettingsTypeStandard otherwise
 */
@property(nonatomic,readonly)NMSMapSettingsType type;

/*! @brief The map mode */
@property(nonatomic,readonly)NMSMapMode mapMode;

/*! @brief The depth unit. @c NMSDepthUnitMeters by default */
@property(nonatomic,readonly)NMSDepthUnit depthUnit;

/*! @brief The speed unit. @c NMSSpeedUnitKPH by default */
@property(nonatomic,readonly)NMSSpeedUnit speedUnit;

/*! @brief The distance unit. @c NMSDistanceUnitKilometers by default */
@property(nonatomic,readonly)NMSDistanceUnit distanceUnit;

/*! @brief The density of the depth contours. Very High by default */
@property(nonatomic,readonly)NMSDepthContoursDensity depthContoursDensity;

/*! @brief Enable the easy view. All the labels and icons will be drawn bigger. NO by default */
@property(nonatomic,readonly)BOOL easyViewEnabled;

/*! @brief The depth contours visibility threshold in the current depth unit. Will be ignored when @c depthContoursAll is enabled
 *  @discussion Can't be lower then @c depthAreas or @c fishingAreaRangeLowerMin. 
 *  @discussion It is automatically aligned when @c depthAreas or @c fishingAreaRangeLowerMin change.
 */
@property(nonatomic,readonly)int depthContours;

/*! @brief The current min valid value for @c depthContours
 *  @discussion It is automatically aligned when @c depthAreas or @c fishingAreaRangeLowerMin change.
 */
@property(nonatomic,readonly)int depthContoursMin;

/*! @brief The current max valid value for @c depthContours*/
@property(nonatomic,readonly)int depthContoursMax;

/*! @brief Enable all the depth contours. When enabled @c depthContours will be ignored. YES by default*/
@property(nonatomic,readonly)BOOL depthContoursAll;

/*! @brief The depth areas visibility threshold in the current depth unit. 20 by default (in the default depth unit) 
 *  @discussion Can't be lower then @c shallowDepthLimit. 
 *  @discussion It is automatically aligned when @c shallowDepthLimit change.
 */
@property(nonatomic,readonly)int depthAreas;

/*! @brief The current min valid value for @c depthAreas
 *  @discussion It is automatically aligned when @c shallowDepthLimit change.
 */
@property(nonatomic,readonly)int depthAreasMin;

/*! @brief The current max valid value for @c depthAreas*/
@property(nonatomic,readonly)int depthAreasMax;

/*! @brief The water level in the current depth unit. 0 by default */
@property(nonatomic,readonly)int poolWaterLevel;

/*! @brief The current min valid value for @c poolWaterLevel */
@property(nonatomic,readonly)int poolWaterLevelMin;

/*! @brief The current max valid value for @c poolWaterLevel */
@property(nonatomic,readonly)int poolWaterLevelMax;

/*! @brief The shallow areas visibility threshold in the current depth unit. 0 by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced. 
 *  @discussion Will affect @c depthAreasMin, @c fishingAreaRangeLowerMin and @c fishingAreaRangeUpperMin
 */
@property(nonatomic,readonly)int shallowDepthLimit;

/*! @brief The current min valid value for @c shallowDepthLimit */
@property(nonatomic,readonly)int shallowDepthLimitMin;

/*! @brief The current max valid value for @c shallowDepthLimit */
@property(nonatomic,readonly)int shallowDepthLimitMax;

/*! @brief Enable the couloured Seabed Area. NO by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 */
@property(nonatomic,readonly)BOOL seabedAreaEnabled;

/*! @brief Enable the Fishing Mode. NO by default 
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 */
@property(nonatomic,readonly)BOOL fishingModeEnabled;

/*! @brief The lower depth value of the fishing area range. Needs Fishing Mode enabled. 0 by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced. 
 *  @discussion Can't be lower then @c shallowDepthLimit. 
 *  @discussion It is automatically aligned when @c shallowDepthLimit change.
 */
@property(nonatomic,readonly)int fishingAreaRangeLower;

/*! @brief The current min valid value for @c fishingAreaRangeLower
 *  @discussion It is automatically aligned when @c shallowDepthLimit change.
 */
@property(nonatomic,readonly)int fishingAreaRangeLowerMin;

/*! @brief The current max valid value for @c fishingAreaRangeLower */
@property(nonatomic,readonly)int fishingAreaRangeLowerMax;

/*! @brief The upper depth value of the fishing area range. Needs Fishing Mode enabled. 0 by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 */
@property(nonatomic,readonly)int fishingAreaRangeUpper;

/*! @brief The current min valid value for @c fishingAreaRangeUpper */
@property(nonatomic,readonly)int fishingAreaRangeUpperMin;

/*! @brief The current max valid value for @c fishingAreaRangeUpper */
@property(nonatomic,readonly)int fishingAreaRangeUpperMax;


@end

/*! @brief Dynamic settings of the map */
@interface NMSMapSettingsEdit : NMSMapSettings

/*! @brief The map mode */
@property(nonatomic,assign)NMSMapMode mapMode;

/*! @brief The depth unit. @c NMSDepthUnitMeters by default */
@property(nonatomic,assign)NMSDepthUnit depthUnit;

/*! @brief The speed unit. @c NMSSpeedUnitKPH by default */
@property(nonatomic,assign)NMSSpeedUnit speedUnit;

/*! @brief The distance unit. @c NMSDistanceUnitKilometers by default */
@property(nonatomic,assign)NMSDistanceUnit distanceUnit;

/*! @brief The density of the depth contours. Very High by default */
@property(nonatomic,assign)NMSDepthContoursDensity depthContoursDensity;

/*! @brief Enable the easy view. All the labels and icons will be drawn bigger. NO by default */
@property(nonatomic,assign)BOOL easyViewEnabled;

/*! @brief The depth contours visibility threshold in the current depth unit. Will be ignored when @c depthContoursAll is enabled
 *  @discussion Can't be lower then @c depthAreas or @c fishingAreaRangeLowerMin. 
 *  @discussion It is automatically aligned when @c depthAreas or @c fishingAreaRangeLowerMin change.
 */
@property(nonatomic,assign)int depthContours;

/*! @brief Enable all the depth contours. When enabled @c depthContours will be ignored. YES by default*/
@property(nonatomic,assign)BOOL depthContoursAll;

/*! @brief The depth areas visibility threshold in the current depth unit. 20 by default (in the default depth unit)
 *  @discussion Can't be lower then @c shallowDepthLimit. 
 *  @discussion It is automatically aligned when @c shallowDepthLimit change.
 */
@property(nonatomic,assign)int depthAreas;

/*! @brief The water level in the current depth unit. 0 by default */
@property(nonatomic,assign)int poolWaterLevel;

/*! @brief The shallow areas visibility threshold in the current depth unit. 0 by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 *  @discussion Will affect @c depthAreasMin, @c fishingAreaRangeLowerMin and @c fishingAreaRangeUpperMin
 */
@property(nonatomic,assign)int shallowDepthLimit;

/*! @brief Enable the couloured Seabed Area. NO by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 */
@property(nonatomic,assign)BOOL seabedAreaEnabled;

/*! @brief Enable the Fishing Mode. NO by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 */
@property(nonatomic,assign)BOOL fishingModeEnabled;

/*! @brief The lower depth value of the fishing area range. Needs Fishing Mode enabled. 0 by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 *  @discussion Can't be lower then @c shallowDepthLimit. 
 *  @discussion It is automatically aligned when @c shallowDepthLimit change.
 */
@property(nonatomic,assign)int fishingAreaRangeLower;

/*! @brief The upper depth value of the fishing area range. Needs Fishing Mode enabled. 0 by default
 *  @discussion Advanced map setting. Can be modified only if a @c type is @c NMSMapSettingsTypeAdvanced.
 *  @discussion Can't be lower then @c fishingAreaRangeLower.
 *  @discussion It is automatically aligned when @c fishingAreaRangeLower change.
 */
@property(nonatomic,assign)int fishingAreaRangeUpper;

@end
